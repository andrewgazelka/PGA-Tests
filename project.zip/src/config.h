const bool TRIANGLE = false;
const float BRIGHTNESS_FACTOR = 1.3;